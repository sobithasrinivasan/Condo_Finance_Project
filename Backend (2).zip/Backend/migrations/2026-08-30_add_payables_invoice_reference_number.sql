-- Adds invoice_reference_number to payables.
-- Populated automatically from the extracted invoice's Invoice_Number when an
-- invoice is imported (see ExtractionService._populate_business_tables ->
-- PayableService.create_payable_from_extraction).
--
-- Run once against the application database:
--   mysql -u <user> -p <db_name> < 2026-08-30_add_payables_invoice_reference_number.sql

ALTER TABLE payables
    ADD COLUMN invoice_reference_number VARCHAR(190) NULL AFTER document_extraction_id;
